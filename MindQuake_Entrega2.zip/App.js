import React from 'react';
import AppNavigator from './navigation/AppNavigation';

const App = () => {
  return <AppNavigator />;
};

export default App;
